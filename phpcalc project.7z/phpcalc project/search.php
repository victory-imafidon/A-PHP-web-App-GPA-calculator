<?php
require_once 'database.php';


$search = mysqli_real_escape_string($link, $_GET["query"]);
$query = "SELECT * FROM data WHERE keyword LIKE '%".$search."%'
LIMIT 1 OFFSET 0;";

$result = mysqli_query($link, $query);

if(mysqli_num_rows($result) > 0 )
{

    while($row = mysqli_fetch_array($result))
	{
echo'<form><fieldset>';
$e=unserialize($row['coursename']);	
$f=unserialize($row['courseload']);	
$g=unserialize($row['coursegrade']);	

$j= count($e);

for($i=0; $i<$j; $i++){

  echo"<p><b>";  echo $e[$i]; echo"</b>&nbsp";
  echo"Credit load:&nbsp";  echo $f[$i]; echo","; echo"&nbsp"; echo"Course grade: &nbsp"; 
  
  if($g[$i]== 5)
  {echo "A"; }
  
  elseif($g[$i]== 4)
  {echo "B"; }

  if($g[$i]== 3)
  {echo "C"; }

  if($g[$i]== 2)
  {echo "D"; }

  if($g[$i]== 1)
  {echo "E"; }

  if($g[$i]== 0)
  {echo "F"; }

  echo"</br></p>";

}

echo"<p><b>Total GPA of all courses:&nbsp"; echo $row['valuee']; echo"</b></p>";

       
echo'</fieldset></form>';
    }

    


}else{

echo"<fieldset>";
echo "<h3>Oops Sorry!! No result related to the keyword was found.</h3>";
echo"</fieldset>";

}

?>