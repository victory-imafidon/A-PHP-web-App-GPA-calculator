<?php


//$hn='35.234.148.29';
$hn='127.0.0.1';
$un='root';
$pw='';
$db='result';
$link =mysqli_connect ($hn, $un, $pw, $db);


  ?>
  